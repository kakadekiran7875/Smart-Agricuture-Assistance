// API Configuration
// Backend server IP address and port
const API_CONFIG = {
    BASE_URL: 'http://172.17.75.239:5000',  // Your backend IP
    ENDPOINTS: {
        DIAGNOSE: '/api/diagnose',
        MARKET_PRICES: '/api/market-prices',
        WEATHER: '/api/weather',
        SUBSIDIES: '/api/subsidies',
        EXPERT_REQUEST: '/api/expert-request'
    },
    TIMEOUT: 10000,  // 10 seconds timeout
    USE_FALLBACK: true  // Use simulated data if API fails
};

// Helper function to make API calls
async function apiCall(endpoint, options = {}) {
    const url = `${API_CONFIG.BASE_URL}${endpoint}`;
    
    try {
        console.log(`API Call: ${url}`);
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), API_CONFIG.TIMEOUT);
        
        const response = await fetch(url, {
            ...options,
            signal: controller.signal,
            headers: {
                ...options.headers,
            }
        });
        
        clearTimeout(timeoutId);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log(`API Response:`, data);
        return { success: true, data };
        
    } catch (error) {
        console.error(`API Error (${endpoint}):`, error.message);
        
        if (API_CONFIG.USE_FALLBACK) {
            console.log('Using fallback data...');
            return { success: false, error: error.message, useFallback: true };
        }
        
        return { success: false, error: error.message };
    }
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { API_CONFIG, apiCall };
}
