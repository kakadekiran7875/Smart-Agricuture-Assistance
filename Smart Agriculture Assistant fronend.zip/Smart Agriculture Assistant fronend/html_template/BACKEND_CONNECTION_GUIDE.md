# Backend Connection Configuration Guide

## ✅ Configuration Complete!

Your frontend is now configured to connect to your backend server at:

**Backend IP:** `172.17.75.239`  
**Backend Port:** `5000`  
**Full URL:** `http://172.17.75.239:5000`

---

## 📁 Files Modified

### 1. **config.js** (NEW)
- Created API configuration file
- Contains backend URL and all endpoint definitions
- Includes automatic fallback to demo data if API fails

### 2. **All HTML Files Updated**
- ✅ `index.html` - Added config.js script
- ✅ `diagnosis.html` - Added config.js script
- ✅ `market.html` - Added config.js script + Fixed CSS error
- ✅ `subsidies.html` - Added config.js script
- ✅ `weather.html` - Added config.js script

### 3. **script.js**
- Updated `simulateAIDiagnosis()` to call backend API
- Falls back to demo data if API is unavailable

### 4. **API_DOCUMENTATION.md**
- Updated with new backend IP and port
- Added firewall configuration notes

---

## 🔧 Backend Requirements

Your backend server must provide these endpoints:

### Required Endpoints:

1. **POST** `/api/diagnose` - Crop disease diagnosis
   - Accepts: `multipart/form-data` with image file
   - Returns: JSON with disease, confidence, treatment, prevention

2. **GET** `/api/market-prices` - Market prices data
   - Returns: JSON with crop prices and market info

3. **GET** `/api/weather` - Weather forecast
   - Returns: JSON with current weather and 5-day forecast

4. **POST** `/api/expert-request` (Optional)
   - Accepts: JSON with farmer details
   - Returns: Confirmation message

---

## 🌐 CORS Configuration (CRITICAL!)

Your backend MUST enable CORS to allow frontend requests:

### Python Flask Example:
```python
from flask import Flask
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes
```

### Manual CORS Headers:
```python
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
    response.headers.add('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
    return response
```

---

## 🔥 Firewall Configuration

Make sure port 5000 is open on your backend server:

### Windows Firewall:
```powershell
New-NetFirewallRule -DisplayName "Flask Backend" -Direction Inbound -LocalPort 5000 -Protocol TCP -Action Allow
```

### Linux (Ubuntu/Debian):
```bash
sudo ufw allow 5000/tcp
sudo ufw reload
```

---

## 🧪 Testing the Connection

### Step 1: Start Your Backend
Make sure your backend is running on `172.17.75.239:5000`

### Step 2: Start Frontend Dev Server
```bash
npm run dev
```

### Step 3: Open Browser Console
Press `F12` and check the Console tab for API logs:
- ✅ Success: `API Call: http://172.17.75.239:5000/api/...`
- ✅ Success: `API Response: {...}`
- ❌ Error: `API Error: ...` (will use fallback data)

### Step 4: Test Features
1. **Diagnosis Page** - Upload an image and click "Analyze Crop"
2. **Market Page** - Check if prices load
3. **Weather Page** - Verify weather data displays

---

## 🔍 Troubleshooting

### Problem: "Failed to fetch" or "Network Error"

**Possible Causes:**
1. ❌ Backend server is not running
2. ❌ Wrong IP address or port
3. ❌ Firewall blocking port 5000
4. ❌ CORS not enabled on backend

**Solutions:**
1. Verify backend is running: `curl http://172.17.75.239:5000/api/market-prices`
2. Check firewall settings
3. Enable CORS on backend
4. Check browser console for detailed error messages

---

### Problem: "CORS policy blocked"

**Solution:**
Add CORS headers to your backend. See CORS Configuration section above.

---

### Problem: API calls timeout

**Solution:**
1. Check if backend server is accessible from your network
2. Increase timeout in `config.js` (default: 10 seconds)
3. Verify network connectivity: `ping 172.17.75.239`

---

## 📝 Configuration File Reference

### config.js Settings:

```javascript
const API_CONFIG = {
    BASE_URL: 'http://172.17.75.239:5000',  // Your backend IP
    ENDPOINTS: {
        DIAGNOSE: '/api/diagnose',
        MARKET_PRICES: '/api/market-prices',
        WEATHER: '/api/weather',
        SUBSIDIES: '/api/subsidies',
        EXPERT_REQUEST: '/api/expert-request'
    },
    TIMEOUT: 10000,  // 10 seconds
    USE_FALLBACK: true  // Use demo data if API fails
};
```

### To Change Backend IP:
Edit `config.js` line 3:
```javascript
BASE_URL: 'http://YOUR_NEW_IP:PORT',
```

---

## 🎯 How It Works

1. **Frontend makes API call** → Uses `apiCall()` function from `config.js`
2. **Request sent to backend** → `http://172.17.75.239:5000/api/...`
3. **Backend responds** → Returns JSON data
4. **Frontend displays data** → Updates UI with real data

### If Backend Fails:
1. **Error logged** → Console shows error message
2. **Fallback activated** → Uses demo/simulated data
3. **App continues** → User experience not interrupted

---

## ✅ Verification Checklist

Before going live, verify:

- [ ] Backend server running on `172.17.75.239:5000`
- [ ] CORS enabled on backend
- [ ] Firewall allows port 5000
- [ ] All API endpoints implemented
- [ ] Frontend can reach backend (test with curl/browser)
- [ ] Browser console shows successful API calls
- [ ] Image upload works in diagnosis page
- [ ] Market prices load correctly
- [ ] Weather data displays properly

---

## 📞 API Call Examples

### From Browser Console:
```javascript
// Test market prices API
fetch('http://172.17.75.239:5000/api/market-prices')
  .then(res => res.json())
  .then(data => console.log(data));

// Test weather API
fetch('http://172.17.75.239:5000/api/weather')
  .then(res => res.json())
  .then(data => console.log(data));
```

### Using curl:
```bash
# Test market prices
curl http://172.17.75.239:5000/api/market-prices

# Test weather
curl http://172.17.75.239:5000/api/weather

# Test diagnosis (with image)
curl -X POST -F "image=@crop.jpg" http://172.17.75.239:5000/api/diagnose
```

---

## 🚀 Ready to Deploy!

Your frontend is now fully configured to connect to your backend at `172.17.75.239:5000`.

**Next Steps:**
1. Ensure your backend is running and accessible
2. Start the frontend: `npm run dev`
3. Test all features
4. Check browser console for any errors
5. Deploy to production when ready!

---

**Configuration Date:** October 15, 2025  
**Backend IP:** 172.17.75.239  
**Backend Port:** 5000  
**Status:** ✅ Ready for Testing
