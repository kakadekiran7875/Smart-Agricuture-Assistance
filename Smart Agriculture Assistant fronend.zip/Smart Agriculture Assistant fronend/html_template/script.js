// Language translations
const translations = {
    en: {
        appTitle: "🌱 Smart Agriculture Assistant",
        appSubtitle: "Your Expert Farming Companion",
        heroTitle: "Empowering Farmers with AI Technology",
        heroDescription: "Get instant crop diagnosis, market prices, and government subsidy information - all in your local language!",
        statFarmers: "Farmers Helped",
        statAccuracy: "Diagnosis Accuracy",
        statSupport: "Available",
        featuresTitle: "Our Services",
        diagnosisTitle: "Crop Diagnosis",
        diagnosisDesc: "Upload photos of your crops and get instant AI-powered disease diagnosis with treatment recommendations.",
        diagnosisAction: "Diagnose Now →",
        marketTitle: "Market Prices",
        marketDesc: "Get real-time market prices for your crops across different mandis and make informed selling decisions.",
        marketAction: "Check Prices →",
        subsidiesTitle: "Government Subsidies",
        subsidiesDesc: "Discover available government schemes, subsidies, and financial assistance programs for farmers.",
        subsidiesAction: "Explore Schemes →",
        weatherTitle: "Weather Forecast",
        weatherDesc: "Get accurate weather forecasts and farming advisories to plan your agricultural activities.",
        weatherAction: "View Weather →",
        quickTitle: "Quick Actions",
        emergencyBtn: "Emergency Help",
        photoBtn: "Take Photo",
        expertBtn: "Contact Expert",
        footerAbout: "About Us",
        footerDesc: "Empowering farmers with technology to improve crop yields and farming decisions.",
        footerContact: "Contact",
        footerSupport: "Support",
        footerHours: "Available 24/7",
        footerLang: "Multiple Languages",
        footerCopy: "© 2024 Smart Agriculture Assistant. Made for farmers, by farmers.",
        emergencyTitle: "Emergency Agricultural Help",
        pestControl: "Pest Control Emergency",
        diseaseOutbreak: "Disease Outbreak",
        weatherAlert: "Weather Alert",
        expertContactTitle: "Contact Agricultural Expert",
        submitExpert: "Request Expert Call",
        langText: "हिन्दी"
    },
    kn: {
        appTitle: "🌱 ಸ್ಮಾರ್ಟ್ ಕೃಷಿ ಸಹಾಯಕ",
        appSubtitle: "ನಿಮ್ಮ ತಜ್ಞ ಕೃಷಿ ಸಂಗಾತಿ",
        heroTitle: "AI ತಂತ್ರಜ್ಞಾನದೊಂದಿಗೆ ರೈತರನ್ನು ಸಶಕ್ತಗೊಳಿಸುವುದು",
        heroDescription: "ತ್ವರಿತ ಬೆಳೆ ರೋಗನಿರ್ಣಯ, ಮಾರುಕಟ್ಟೆ ಬೆಲೆಗಳು ಮತ್ತು ಸರ್ಕಾರಿ ಸಬ್ಸಿಡಿ ಮಾಹಿತಿಯನ್ನು ಪಡೆಯಿರಿ - ಎಲ್ಲವೂ ನಿಮ್ಮ ಸ್ಥಳೀಯ ಭಾಷೆಯಲ್ಲಿ!",
        statFarmers: "ಸಹಾಯ ಮಾಡಿದ ರೈತರು",
        statAccuracy: "ರೋಗನಿರ್ಣಯ ನಿಖರತೆ",
        statSupport: "ಲಭ್ಯವಿದೆ",
        featuresTitle: "ನಮ್ಮ ಸೇವೆಗಳು",
        diagnosisTitle: "ಬೆಳೆ ರೋಗನಿರ್ಣಯ",
        diagnosisDesc: "ನಿಮ್ಮ ಬೆಳೆಗಳ ಫೋಟೋಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ ಮತ್ತು ಚಿಕಿತ್ಸೆಯ ಶಿಫಾರಸುಗಳೊಂದಿಗೆ ತ್ವರಿತ AI-ಚಾಲಿತ ರೋಗ ರೋಗನಿರ್ಣಯವನ್ನು ಪಡೆಯಿರಿ.",
        diagnosisAction: "ಈಗ ರೋಗನಿರ್ಣಯ ಮಾಡಿ →",
        marketTitle: "ಮಾರುಕಟ್ಟೆ ಬೆಲೆಗಳು",
        marketDesc: "ವಿವಿಧ ಮಂಡಿಗಳಲ್ಲಿ ನಿಮ್ಮ ಬೆಳೆಗಳಿಗೆ ನೈಜ-ಸಮಯದ ಮಾರುಕಟ್ಟೆ ಬೆಲೆಗಳನ್ನು ಪಡೆಯಿರಿ ಮತ್ತು ತಿಳುವಳಿಕೆಯುಳ್ಳ ಮಾರಾಟದ ನಿರ್ಧಾರಗಳನ್ನು ತೆಗೆದುಕೊಳ್ಳಿ.",
        marketAction: "ಬೆಲೆಗಳನ್ನು ಪರಿಶೀಲಿಸಿ →",
        subsidiesTitle: "ಸರ್ಕಾರಿ ಸಬ್ಸಿಡಿಗಳು",
        subsidiesDesc: "ರೈತರಿಗೆ ಲಭ್ಯವಿರುವ ಸರ್ಕಾರಿ ಯೋಜನೆಗಳು, ಸಬ್ಸಿಡಿಗಳು ಮತ್ತು ಆರ್ಥಿಕ ಸಹಾಯ ಕಾರ್ಯಕ್ರಮಗಳನ್ನು ಅನ್ವೇಷಿಸಿ.",
        subsidiesAction: "ಯೋಜನೆಗಳನ್ನು ಅನ್ವೇಷಿಸಿ →",
        weatherTitle: "ಹವಾಮಾನ ಮುನ್ನೋಟ",
        weatherDesc: "ನಿಮ್ಮ ಕೃಷಿ ಚಟುವಟಿಕೆಗಳನ್ನು ಯೋಜಿಸಲು ನಿಖರವಾದ ಹವಾಮಾನ ಮುನ್ನೋಟಗಳು ಮತ್ತು ಕೃಷಿ ಸಲಹೆಗಳನ್ನು ಪಡೆಯಿರಿ.",
        weatherAction: "ಹವಾಮಾನ ವೀಕ್ಷಿಸಿ →",
        quickTitle: "ತ್ವರಿತ ಕ್ರಿಯೆಗಳು",
        emergencyBtn: "ತುರ್ತು ಸಹಾಯ",
        photoBtn: "ಫೋಟೋ ತೆಗೆಯಿರಿ",
        expertBtn: "ತಜ್ಞರನ್ನು ಸಂಪರ್ಕಿಸಿ",
        footerAbout: "ನಮ್ಮ ಬಗ್ಗೆ",
        footerDesc: "ಬೆಳೆ ಇಳುವರಿ ಮತ್ತು ಕೃಷಿ ನಿರ್ಧಾರಗಳನ್ನು ಸುಧಾರಿಸಲು ತಂತ್ರಜ್ಞಾನದೊಂದಿಗೆ ರೈತರನ್ನು ಸಶಕ್ತಗೊಳಿಸುವುದು.",
        footerContact: "ಸಂಪರ್ಕ",
        footerSupport: "ಬೆಂಬಲ",
        footerHours: "24/7 ಲಭ್ಯವಿದೆ",
        footerLang: "ಬಹು ಭಾಷೆಗಳು",
        footerCopy: "© 2024 ಸ್ಮಾರ್ಟ್ ಕೃಷಿ ಸಹಾಯಕ. ರೈತರಿಗಾಗಿ, ರೈತರಿಂದ ಮಾಡಲಾಗಿದೆ.",
        emergencyTitle: "ತುರ್ತು ಕೃಷಿ ಸಹಾಯ",
        pestControl: "ಕೀಟ ನಿಯಂತ್ರಣ ತುರ್ತು",
        diseaseOutbreak: "ರೋಗ ಏಕಾಏಕಿ",
        weatherAlert: "ಹವಾಮಾನ ಎಚ್ಚರಿಕೆ",
        expertContactTitle: "ಕೃಷಿ ತಜ್ಞರನ್ನು ಸಂಪರ್ಕಿಸಿ",
        submitExpert: "ತಜ್ಞ ಕರೆಗೆ ವಿನಂತಿಸಿ",
        langText: "मराठी"
    },
    hi: {
        appTitle: "🌱 स्मार्ट कृषि सहायक",
        appSubtitle: "आपका विशेषज्ञ कृषि साथी",
        heroTitle: "AI तकनीक के साथ किसानों को सशक्त बनाना",
        heroDescription: "तुरंत फसल निदान, बाजार की कीमतें और सरकारी सब्सिडी की जानकारी प्राप्त करें - सब कुछ आपकी स्थानीय भाषा में!",
        statFarmers: "सहायता प्राप्त किसान",
        statAccuracy: "निदान सटीकता",
        statSupport: "उपलब्ध",
        featuresTitle: "हमारी सेवाएं",
        diagnosisTitle: "फसल निदान",
        diagnosisDesc: "अपनी फसलों की तस्वीरें अपलोड करें और उपचार सुझावों के साथ तुरंत AI-संचालित रोग निदान प्राप्त करें।",
        diagnosisAction: "अब निदान करें →",
        marketTitle: "बाजार की कीमतें",
        marketDesc: "विभिन्न मंडियों में अपनी फसलों की वास्तविक समय की बाजार कीमतें प्राप्त करें और सूचित बिक्री निर्णय लें।",
        marketAction: "कीमतें जांचें →",
        subsidiesTitle: "सरकारी सब्सिडी",
        subsidiesDesc: "किसानों के लिए उपलब्ध सरकारी योजनाओं, सब्सिडी और वित्तीय सहायता कार्यक्रमों की खोज करें।",
        subsidiesAction: "योजनाएं देखें →",
        weatherTitle: "मौसम पूर्वानुमान",
        weatherDesc: "अपनी कृषि गतिविधियों की योजना बनाने के लिए सटीक मौसम पूर्वानुमान और कृषि सलाह प्राप्त करें।",
        weatherAction: "मौसम देखें →",
        quickTitle: "त्वरित कार्य",
        emergencyBtn: "आपातकालीन सहायता",
        photoBtn: "फोटो लें",
        expertBtn: "विशेषज्ञ से संपर्क करें",
        footerAbout: "हमारे बारे में",
        footerDesc: "फसल उत्पादन और कृषि निर्णयों में सुधार के लिए तकनीक के साथ किसानों को सशक्त बनाना।",
        footerContact: "संपर्क",
        footerSupport: "सहायता",
        footerHours: "24/7 उपलब्ध",
        footerLang: "कई भाषाएं",
        footerCopy: "© 2024 स्मार्ट कृषि सहायक। किसानों के लिए, किसानों द्वारा बनाया गया।",
        emergencyTitle: "आपातकालीन कृषि सहायता",
        pestControl: "कीट नियंत्रण आपातकाल",
        diseaseOutbreak: "रोग प्रकोप",
        weatherAlert: "मौसम चेतावनी",
        expertContactTitle: "कृषि विशेषज्ञ से संपर्क करें",
        submitExpert: "विशेषज्ञ कॉल का अनुरोध करें",
        langText: "मराठी"
    },
    mr: {
        appTitle: "🌱 स्मार्ट शेती सहाय्यक",
        appSubtitle: "तुमचा तज्ञ शेती साथीदार",
        heroTitle: "AI तंत्रज्ञानासह शेतकऱ्यांना सशक्त करणे",
        heroDescription: "तत्काळ पीक निदान, बाजार भाव आणि सरकारी अनुदान माहिती मिळवा - सर्व काही तुमच्या स्थानिक भाषेत!",
        statFarmers: "मदत केलेले शेतकरी",
        statAccuracy: "निदान अचूकता",
        statSupport: "उपलब्ध",
        featuresTitle: "आमच्या सेवा",
        diagnosisTitle: "पीक निदान",
        diagnosisDesc: "तुमच्या पिकांचे फोटो अपलोड करा आणि उपचार शिफारशींसह तत्काळ AI-चालित रोग निदान मिळवा।",
        diagnosisAction: "आता निदान करा →",
        marketTitle: "बाजार भाव",
        marketDesc: "विविध मंडींमध्ये तुमच्या पिकांचे रिअल-टाइम बाजार भाव मिळवा आणि माहितीपूर्ण विक्री निर्णय घ्या।",
        marketAction: "भाव तपासा →",
        subsidiesTitle: "सरकारी अनुदान",
        subsidiesDesc: "शेतकऱ्यांसाठी उपलब्ध सरकारी योजना, अनुदान आणि आर्थिक सहाय्य कार्यक्रम शोधा।",
        subsidiesAction: "योजना पहा →",
        weatherTitle: "हवामान अंदाज",
        weatherDesc: "तुमच्या शेती क्रियाकलापांची योजना करण्यासाठी अचूक हवामान अंदाज आणि शेती सल्ला मिळवा।",
        weatherAction: "हवामान पहा →",
        quickTitle: "त्वरित कृती",
        emergencyBtn: "आपत्कालीन मदत",
        photoBtn: "फोटो काढा",
        expertBtn: "तज्ञाशी संपर्क करा",
        footerAbout: "आमच्याबद्दल",
        footerDesc: "पीक उत्पादन आणि शेती निर्णयांमध्ये सुधारणा करण्यासाठी तंत्रज्ञानासह शेतकऱ्यांना सशक्त करणे।",
        footerContact: "संपर्क",
        footerSupport: "सहाय्य",
        footerHours: "24/7 उपलब्ध",
        footerLang: "अनेक भाषा",
        footerCopy: "© 2024 स्मार्ट शेती सहाय्यक। शेतकऱ्यांसाठी, शेतकऱ्यांनी बनवलेले।",
        emergencyTitle: "आपत्कालीन शेती मदत",
        pestControl: "कीड नियंत्रण आपत्काल",
        diseaseOutbreak: "रोग प्रसार",
        weatherAlert: "हवामान चेतावणी",
        expertContactTitle: "शेती तज्ञाशी संपर्क करा",
        submitExpert: "तज्ञ कॉलची विनंती करा",
        langText: "English"
    }
};

// Current language state
let currentLang = 'en';
const languages = ['en', 'kn', 'hi', 'mr'];
let currentLangIndex = 0;

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    console.log('Smart Agriculture Assistant loaded!');
    
    // Check for saved language preference
    const savedLang = localStorage.getItem('preferredLanguage');
    if (savedLang && languages.includes(savedLang)) {
        currentLang = savedLang;
        currentLangIndex = languages.indexOf(currentLang);
        updateLanguage();
    }
    
    // Initialize expert form submission
    initializeExpertForm();
    
    // Add click outside modal to close
    window.onclick = function(event) {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    }
});

// Language toggle functionality - now cycles through all 4 languages
function toggleLanguage() {
    currentLangIndex = (currentLangIndex + 1) % languages.length;
    currentLang = languages[currentLangIndex];
    localStorage.setItem('preferredLanguage', currentLang);
    updateLanguage();
}

function updateLanguage() {
    const elements = translations[currentLang];
    
    Object.keys(elements).forEach(key => {
        const element = document.getElementById(key);
        if (element) {
            element.textContent = elements[key];
        }
    });
}

// Navigation functions
function navigateTo(page) {
    window.location.href = page;
}

function goBack() {
    window.history.back();
}

// Modal functions
function showEmergencyHelp() {
    document.getElementById('emergencyModal').style.display = 'block';
}

function showExpertContact() {
    document.getElementById('expertModal').style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Expert form initialization
function initializeExpertForm() {
    const expertForm = document.querySelector('.expert-form');
    if (expertForm) {
        expertForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = {
                name: document.getElementById('farmerName').value,
                phone: document.getElementById('farmerPhone').value,
                cropType: document.getElementById('cropType').value,
                issue: document.getElementById('issueDescription').value
            };
            
            // Multi-language success messages
            const successMessages = {
                en: `Thank you ${formData.name}! An agricultural expert will call you within 30 minutes at ${formData.phone}.`,
                kn: `ಧನ್ಯವಾದಗಳು ${formData.name}! ಕೃಷಿ ತಜ್ಞರು 30 ನಿಮಿಷಗಳಲ್ಲಿ ${formData.phone} ನಲ್ಲಿ ನಿಮಗೆ ಕರೆ ಮಾಡುತ್ತಾರೆ.`,
                hi: `धन्यवाद ${formData.name}! एक कृषि विशेषज्ञ 30 मिनट के भीतर ${formData.phone} पर आपको कॉल करेगा।`,
                mr: `धन्यवाद ${formData.name}! एक शेती तज्ञ 30 मिनिटांत ${formData.phone} वर तुम्हाला कॉल करेल।`
            };
            
            alert(successMessages[currentLang]);
            
            closeModal('expertModal');
            expertForm.reset();
        });
    }
}

// Utility functions for other pages
function showLoading(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = '<div class="loading">Loading...</div>';
    }
}

function hideLoading(elementId, content) {
    const element = document.getElementById(elementId);
    if (element) {
        element.innerHTML = content;
    }
}

// Image upload and preview functionality
function handleImageUpload(inputElement, previewElement) {
    const file = inputElement.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            previewElement.src = e.target.result;
            previewElement.style.display = 'block';
        };
        reader.readAsDataURL(file);
    }
}

// AI diagnosis function with API integration
async function simulateAIDiagnosis(imageFile) {
    // Try to call backend API first
    if (typeof apiCall !== 'undefined') {
        const formData = new FormData();
        formData.append('image', imageFile);
        
        const result = await apiCall(API_CONFIG.ENDPOINTS.DIAGNOSE, {
            method: 'POST',
            body: formData
        });
        
        if (result.success) {
            return result.data;
        }
    }
    
    // Fallback: Simulate processing time with demo data
    return new Promise((resolve) => {
        setTimeout(() => {
            const diagnoses = [
                {
                    disease: "Early Blight",
                    confidence: 92,
                    treatment: "Apply copper-based fungicide every 7-10 days. Remove affected leaves.",
                    prevention: "Ensure proper spacing between plants for air circulation."
                },
                {
                    disease: "Tomato Mosaic Virus",
                    confidence: 87,
                    treatment: "Remove infected plants immediately. Use virus-resistant varieties.",
                    prevention: "Control aphids and whiteflies. Sanitize tools between plants."
                },
                {
                    disease: "Nutrient Deficiency (Nitrogen)",
                    confidence: 78,
                    treatment: "Apply nitrogen-rich fertilizer. Use organic compost.",
                    prevention: "Regular soil testing and balanced fertilization."
                }
            ];
            
            // Return random diagnosis for demo
            const randomIndex = Math.floor(Math.random() * diagnoses.length);
            resolve(diagnoses[randomIndex]);
        }, 2000);
    });
}

// Market price simulation
function getMarketPrices() {
    return {
        tomato: { price: 25, change: +5, market: "Bangalore APMC" },
        onion: { price: 18, change: -2, market: "Mysore Mandi" },
        potato: { price: 22, change: +3, market: "Hassan Market" },
        rice: { price: 2800, change: +50, market: "Mandya APMC" },
        wheat: { price: 2200, change: -30, market: "Tumkur Mandi" }
    };
}

// Weather simulation
function getWeatherData() {
    return {
        current: {
            temperature: 28,
            humidity: 65,
            rainfall: 0,
            windSpeed: 12,
            condition: "Partly Cloudy"
        },
        forecast: [
            { day: "Today", temp: "28°C", condition: "Partly Cloudy", rain: "10%" },
            { day: "Tomorrow", temp: "30°C", condition: "Sunny", rain: "5%" },
            { day: "Day 3", temp: "26°C", condition: "Rainy", rain: "80%" },
            { day: "Day 4", temp: "24°C", condition: "Cloudy", rain: "40%" },
            { day: "Day 5", temp: "29°C", condition: "Sunny", rain: "0%" }
        ],
        advisory: "Good conditions for spraying pesticides. Avoid irrigation for next 2 days due to expected rainfall."
    };
}