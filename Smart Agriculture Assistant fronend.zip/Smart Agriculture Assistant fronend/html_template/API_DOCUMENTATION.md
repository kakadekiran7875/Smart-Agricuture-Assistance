# Backend API Documentation

Your frontend is now configured to connect to: **http://172.17.75.239:5000**

## Required API Endpoints

### 1. Crop Diagnosis API
**Endpoint:** `POST /api/diagnose`  
**Content-Type:** `multipart/form-data`

**Request Body:**
- `image`: File (crop image)

**Response Format:**
```json
{
  "disease": "Early Blight",
  "confidence": 92,
  "treatment": "Apply copper-based fungicide every 7-10 days. Remove affected leaves.",
  "prevention": "Ensure proper spacing between plants for air circulation."
}
```

---

### 2. Market Prices API
**Endpoint:** `GET /api/market-prices`

**Response Format:**
```json
{
  "tomato": {
    "price": 25,
    "change": 5,
    "market": "Bangalore APMC"
  },
  "onion": {
    "price": 18,
    "change": -2,
    "market": "Mysore Mandi"
  },
  "potato": {
    "price": 22,
    "change": 3,
    "market": "Hassan Market"
  },
  "rice": {
    "price": 2800,
    "change": 50,
    "market": "Mandya APMC"
  },
  "wheat": {
    "price": 2200,
    "change": -30,
    "market": "Tumkur Mandi"
  }
}
```

---

### 3. Weather Data API
**Endpoint:** `GET /api/weather`

**Response Format:**
```json
{
  "current": {
    "temperature": 28,
    "humidity": 65,
    "rainfall": 0,
    "windSpeed": 12,
    "condition": "Partly Cloudy"
  },
  "forecast": [
    {
      "day": "Today",
      "temp": "28°C",
      "condition": "Partly Cloudy",
      "rain": "10%"
    },
    {
      "day": "Tomorrow",
      "temp": "30°C",
      "condition": "Sunny",
      "rain": "5%"
    },
    {
      "day": "Day 3",
      "temp": "26°C",
      "condition": "Rainy",
      "rain": "80%"
    },
    {
      "day": "Day 4",
      "temp": "24°C",
      "condition": "Cloudy",
      "rain": "40%"
    },
    {
      "day": "Day 5",
      "temp": "29°C",
      "condition": "Sunny",
      "rain": "0%"
    }
  ],
  "advisory": "Good conditions for spraying pesticides. Avoid irrigation for next 2 days due to expected rainfall."
}
```

---

## CORS Configuration

Your backend must enable CORS to allow requests from the frontend. Add these headers:

```
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET, POST, OPTIONS
Access-Control-Allow-Headers: Content-Type
```

---

## Fallback Behavior

The frontend includes fallback data for all APIs. If your backend is not running or returns an error:
- Users will see simulated/demo data
- Error messages will appear in the browser console
- The app will continue to function with static data

---

## Testing Your Backend

1. Start your backend server on port 5000 at IP 172.17.75.239
2. Open the frontend in a browser
3. Check the browser console (F12) for API call logs
4. If you see "API call failed" errors, check:
   - Backend is running on http://172.17.75.239:5000
   - CORS is properly configured
   - Endpoints match the documentation above
   - Firewall allows connections on port 5000

---

## Example Backend (Python Flask)

```python
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/api/diagnose', methods=['POST'])
def diagnose():
    # Process uploaded image
    image = request.files['image']
    # Your AI model logic here
    return jsonify({
        "disease": "Early Blight",
        "confidence": 92,
        "treatment": "Apply copper-based fungicide...",
        "prevention": "Ensure proper spacing..."
    })

@app.route('/api/market-prices', methods=['GET'])
def market_prices():
    return jsonify({
        "tomato": {"price": 25, "change": 5, "market": "Bangalore APMC"},
        # ... more crops
    })

@app.route('/api/weather', methods=['GET'])
def weather():
    return jsonify({
        "current": {"temperature": 28, "humidity": 65, ...},
        "forecast": [...],
        "advisory": "..."
    })

if __name__ == '__main__':
    app.run(host='172.17.75.239', port=5000, debug=True)
```
